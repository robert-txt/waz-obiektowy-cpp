#include "Game.hpp"

int main()
{
    Game game;

    game.Run();

    return 0;
}

